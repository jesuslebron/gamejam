using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private float horizontal;
    private float vertical;
    private float speed = 5f;
    private bool movex, movey;
    private bool isFacingRight = true;
    private  Vector3 localPosition;

    [SerializeField] private Rigidbody2D rb;

    void Start()
    {
        localPosition = transform.localPosition;
        movex = false; movey = false;
    }

    void Update()
    {

        horizontal = Input.GetAxisRaw("Horizontal");

        
        vertical = Input.GetAxisRaw("Vertical");

        if (horizontal == -1)
        {
            movex=true;
            movey=false;
            speed = -5;
        } else if (horizontal == 1){
            movex=true;
            movey=false;
            speed  = 5;
        } else if (vertical == -1){
            movex=false;
            movey=true;
            speed  = -5;
        } else if (vertical == 1){
            movex=false;
            movey=true;
            speed  = 5;
        }


        if(movey)
        {
            localPosition.y += speed * Time.deltaTime;
            if (localPosition.y < -4.5f) 
            {
                localPosition.y = -4.5f;
                speed *=-1.0f;
            } else if (localPosition.y > 4.5f)
            {
                localPosition.y = 4.5f;                                
                speed *=-1.0f;
            }

        }else if(movex)
        {
            localPosition.x +=  speed * Time.deltaTime;
            if (localPosition.x < -7.5f) 
            {
                localPosition.x = -7.5f;
                horizontal = 1.0f;
                speed *= -1.0f;
            } else if (localPosition.x > 7.5f)
            {
                localPosition.x = 7.5f;
                horizontal = -1.0f;
                speed *= -1.0f;
            }
        }


        Flip();

        transform.localPosition = localPosition;

    }

    private void Flip()
    {
        if (isFacingRight && horizontal > 0f || !isFacingRight && horizontal < 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }

    
}